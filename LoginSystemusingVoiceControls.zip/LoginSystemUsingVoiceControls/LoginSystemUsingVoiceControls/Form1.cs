﻿using System;
using System.Speech.Recognition;
using System.Speech.Synthesis;
using System.Threading;
using System.Windows.Forms;

namespace LoginSystemUsingVoiceControls
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }
        SpeechSynthesizer speechSynthesizerObj;
        private void Form1_Load(object sender, EventArgs e)
        {
            speechSynthesizerObj = new SpeechSynthesizer();
            speechSynthesizerObj.SpeakAsync("Please say the user name.");
            SpeechRecognitionEngine sRecognize = new SpeechRecognitionEngine();
            Choices sList = new Choices();
            sList.Add(new string[] {
                "kishore"            });
            Grammar gr = new Grammar(new GrammarBuilder(sList));
            try
            {
                sRecognize.RequestRecognizerUpdate();
                sRecognize.LoadGrammar(gr);
                sRecognize.SpeechRecognized += sRecognize_SpeechRecognized;
                sRecognize.SetInputToDefaultAudioDevice();
                sRecognize.RecognizeAsync(RecognizeMode.Multiple);
                sRecognize.Recognize();
            }
            catch
            {
                return;
            }
        }

        private void sRecognize_SpeechRecognized(object sender, SpeechRecognizedEventArgs e)
        {
            if (e.Result.Text == "kishore")
            {
                speechSynthesizerObj = new SpeechSynthesizer();
                speechSynthesizerObj.SpeakAsync("Please say the password.");
                SpeechRecognitionEngine sRecognize = new SpeechRecognitionEngine();
                Choices sList = new Choices();
                sList.Add(new string[] { "chowdary" });
                Grammar gr = new Grammar(new GrammarBuilder(sList));
                Thread.Sleep(500);
                try
                {
                    sRecognize.RequestRecognizerUpdate();
                    sRecognize.LoadGrammar(gr);
                    sRecognize.SpeechRecognized += sRecognize_SpeechRecognized1;
                    sRecognize.SetInputToDefaultAudioDevice();
                    sRecognize.RecognizeAsync(RecognizeMode.Multiple);
                    sRecognize.Recognize();
                }
                catch
                {
                    return;
                }
            }
            else
            {
                speechSynthesizerObj.SpeakAsync("Please say the valid user name.");
                Thread.Sleep(4000);
            }
        }
        private void sRecognize_SpeechRecognized1(object sender, SpeechRecognizedEventArgs e)
        {
            //Thread.Sleep(2500);
            if (e.Result.Text == "chowdary")
            {
                speechSynthesizerObj.SpeakAsync("Login successfull. Welcome");
                Form Form2 = new Form();
                Form2.Show();
                Hide();
            }
        }
    }
}
            

        
    
