﻿namespace LoginSystemUsingVoiceControls
{
    internal class choices
    {
    }
}