﻿namespace LoginSystemUsingVoiceControls
{
    internal class speechrecognitionengine
    {
    }
}